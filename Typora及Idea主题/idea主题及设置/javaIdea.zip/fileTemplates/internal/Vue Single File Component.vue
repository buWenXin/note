<template>
<div>
${COMPONENT_NAME}
</div>
</template>

<script>
export default {
name: "${COMPONENT_NAME}"
}
</script>

<style scoped>

</style>